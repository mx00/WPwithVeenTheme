<?php
require_once(EPCL_PLUGIN_PATH.'/theme-functions/enqueue-scripts.php');    
require_once(EPCL_PLUGIN_PATH.'/theme-functions/render-ads.php');          
require_once(EPCL_PLUGIN_PATH.'/theme-functions/custom-styles.php');  
require_once(EPCL_PLUGIN_PATH.'/theme-functions/social-buttons.php');    
